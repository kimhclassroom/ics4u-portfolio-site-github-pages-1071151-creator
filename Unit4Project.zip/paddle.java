class paddle extends Shape{
    
    int paddleX;
    int paddleY;
    int paddleWidth;
    int paddleHeight;
    int paddleSpeed;
    
    public paddle(int x, int y, int w, int h, int speed){
        this.paddleX = x;
        this.paddleY = y;
        this.paddleWidth = w;
        this.paddleHeight = h;
        this.paddleSpeed = speed;
    }
    @Override
    public void move(int sx, int sy){
        this.paddleX += sx;
        this.paddleY += sy;
    }
    @Override
    public void setPosition(int x, int y){
        this.paddleX = x;
        this.paddleY = y;
    }
    @Override
    public int getX(){
        return paddleX;
    }
    @Override
    public int getY(){
        return paddleY;
    }
    public int getW(){
        return paddleWidth;
    }
    public int getH(){
        return paddleHeight;
    }
    public int getSpeed(){
        return paddleSpeed;
    }
    public void setX(int x){
        this.paddleX = x;
    }
}