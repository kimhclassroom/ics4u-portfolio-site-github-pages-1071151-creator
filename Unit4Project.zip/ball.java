class ball extends Shape{
    
    int ballX;
    int ballY;
    int ballSize;
    int ballSpeedX;
    int ballSpeedY;
    
    public ball(int x, int y, int d, int sX, int sY){
        this.ballX = x;
        this.ballY = y;
        this.ballSize = d;
        this.ballSpeedX = sX;
        this.ballSpeedY = sY;
    }
    @Override
    public void move(int speedX, int speedY){
        this.ballX += speedX;
        this.ballY += speedY;
    }
    @Override
    public void setPosition(int x, int y){
        this.ballX = x;
        this.ballY = y;
    }
    @Override
    public int getX(){
        return ballX;
    }
    @Override
    public int getY(){
        return ballY;
    }
    public int getSize(){
        return ballSize;
    }
    public int getSpeedX(){
        return ballSpeedX;
    }
    public int getSpeedY(){
        return ballSpeedY;
    }
    public void setSpeedX(int sx){
        this.ballSpeedX = sx;
    }
    public void setSpeedY(int sy){
        this.ballSpeedY = sy;
    }
}