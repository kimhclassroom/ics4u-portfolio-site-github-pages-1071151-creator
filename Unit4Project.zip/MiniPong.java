import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class MiniPong extends JPanel implements ActionListener, KeyListener {

    ball b = new ball(200, 150, 20, 0, 0);
    paddle p = new paddle(200, 330, 170, 10, 3);
    
    int sc = 0;
    JLabel score = new JLabel("Score: "+sc);
    
    boolean right = false;
    boolean left = false;
    
    Timer timer;

    public MiniPong() {
        
        JFrame frame = new JFrame("Mini Pong");
        frame.setSize(400, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.addKeyListener(this);
        
        this.add(score);
        
        JButton start = new JButton("start");
        this.add(start);
        start.setFocusable(false);
        
        frame.add(this);
        frame.setVisible(true);
        timer = new Timer(10, this);
        timer.start();
        
        start.addActionListener( e -> {
            String str = JOptionPane.showInputDialog("enter name");
            if (str != null && !str.trim().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Hello, " + str + "!");
                sc = 0;
                score.setText("Score: "+sc);
                b.setSpeedX(1); 
                b.setSpeedY(1);
                b.setPosition(200, 150);
                timer.start();
            } else {
                JOptionPane.showMessageDialog(null, "Name cannot be empty.");
            }
        } );
        
        
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        // Background
        g.setColor(Color.BLACK);
        g.fillRect(0, 0, getWidth(), getHeight());

        // Ball
        g.setColor(Color.WHITE);
        g.fillOval(b.getX(), b.getY(), b.getSize(), b.getSize());

        // Paddle
        g.fillRect(p.getX(), p.getY(), p.getW(), p.getH());
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        
    if(right == true){
        p.move(p.getSpeed(), 0);
    }
    
    if(left == true){
        p.move(-p.getSpeed(), 0);
    }


        // Move ball
        b.move(b.getSpeedX(), b.getSpeedY());

        // Bounce off walls
        if (b.getX() <= 0 || b.getX() >= getWidth() - b.getSize()) {
            b.setSpeedX(-b.getSpeedX());
        }

        if (b.getY() <= 0) {
            b.setSpeedY(-b.getSpeedY());
        }

        // Paddle collision
        Rectangle ball = new Rectangle(b.getX(), b.getY(), b.getSize(), b.getSize());
        Rectangle paddle = new Rectangle(p.getX(), p.getY(), p.getW(), p.getH());

        if (ball.intersects(paddle)) {
            b.setSpeedY(-b.getSpeedY());
            sc++;
            score.setText("Score: "+sc);
        }

        // Game over if ball falls down
        if (b.getY() > getHeight()) {
            timer.stop();
            JOptionPane.showMessageDialog(this, "Game Over!");
            b.setSpeedX(0); 
            b.setSpeedY(0);
        }

        repaint();
    }

    @Override
    public void keyPressed(KeyEvent e) {

        // Move paddle left
        if (e.getKeyCode() == KeyEvent.VK_LEFT) {
            left = true;
        }

        // Move paddle right
        if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
            right = true;
        }

        // Keep paddle inside window
        if (p.getX() < 0) {
            p.setX(0);
        }

        if (p.getX() > getWidth() - p.getW()) {
            p.setX(getWidth() - p.getW());
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_LEFT) {
            left = false;
        }

        if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
            right = false;
        }
    }

    @Override
    public void keyTyped(KeyEvent e) {}

    public static void main(String[] args) {
        new MiniPong();
    }
}