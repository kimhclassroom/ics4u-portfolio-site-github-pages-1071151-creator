public abstract class Shape{
    public abstract void move(int sx, int sy);
    public abstract void setPosition(int x, int y);
    public abstract int getX();
    public abstract int getY();
}